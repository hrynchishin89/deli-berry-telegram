(async () => {
  'use strict';

  let catalog, appConfig;
  try {
    const responses = await Promise.all([fetch('/api/catalog'), fetch('/api/config')]);
    if (responses.some(r => !r.ok)) throw new Error('unavailable');
    [catalog, appConfig] = await Promise.all(responses.map(r => r.json()));
  } catch {
    document.getElementById('app').textContent = 'Не удалось загрузить каталог. Обновите страницу или позвоните +7 (995) 901-47-24.';
    return;
  }
  let serverOrders = [], orderError = '', submitting = false, nextBefore = null, loadingMore = false, ordersInitialized = false;
  const quoteCache = new Map(), slotCache = new Map(), pending = new Set();
  const paymentNotice = appConfig.paymentEnabled ? 'Оплата через Яндекс Пэй появится после подтверждения оператором.' : 'Оператор проверит заказ и свяжется с вами для согласования.';
  async function api(url, options = {}) {
    const response = await fetch(url, {...options, headers: {'Content-Type':'application/json', 'X-Telegram-Init-Data':tg?.initData || '', ...options.headers}});
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || 'Не удалось выполнить запрос. Повторите позже.');
    return data;
  }
  function selection() { return {product:{id:state.productId}, variant:{id:getVariant()?.id}, quantity:state.quantity, addOns:selectedAddOns().map(a=>({id:a.id})), inscriptionText:state.inscription?state.inscriptionText.trim():''}; }
  function quoteKey() { return JSON.stringify(selection()); }
  async function refreshCheckoutData() {
    if (!['product','checkout'].includes(state.route)) return;
    const q = quoteKey();
    if (!quoteCache.has(q) && !pending.has(q)) {
      pending.add(q);
      try { quoteCache.set(q, (await api('/api/quote', {method:'POST',body:q})).total); }
      catch (error) { toast(error.message); }
      finally { pending.delete(q); }
      if (q === quoteKey()) { if (quoteCache.has(q)) render(); }
    }
    if (state.route !== 'checkout') return;
    const key = slotKey();
    if (!slotCache.has(key) && !pending.has(key)) {
      pending.add(key);
      try {
        const result = await api('/api/slots?' + new URLSearchParams({variant:getVariant().id, store:state.checkout.storeId,date:state.checkout.date}));
        slotCache.set(key, {slots:result.slots,at:Date.now()});
      } catch (error) { slotCache.set(key,{slots:[],at:Date.now(),error:error.message}); toast(error.message); }
      finally { pending.delete(key); }
      if (key === slotKey()) render();
    }
  }
  function slotKey() { return [state.variantId,state.checkout.storeId,state.checkout.date].join('|'); }
  async function refreshOrders(more=false) {
    if(loadingMore)return;
    if(more===true&&!nextBefore)return;
    loadingMore=true;
    if (!tg?.initData) { loadingMore=false;orderError='Откройте приложение через Telegram, чтобы увидеть свои заказы.'; if(state.route==='orders')render(); return; }
    try { const result=await api('/api/orders'+(more===true?'?before='+encodeURIComponent(nextBefore):''));
      const merged=new Map(serverOrders.map(o=>[o.id,o]));for(const order of result.orders)merged.set(order.id,order);serverOrders=[...merged.values()];
      if(more===true||!ordersInitialized)nextBefore=result.nextBefore;ordersInitialized=true;orderError='';
      if(['order','success'].includes(state.route)&&state.currentOrderId&&!result.orders.some(o=>o.id===state.currentOrderId)){const current=await api('/api/orders/'+state.currentOrderId);serverOrders=serverOrders.map(o=>o.id===current.order.id?current.order:o);} }
    catch(error) { orderError=error.message; }
    loadingMore=false;
    if(['orders','order','success'].includes(state.route))render();
  }

  const app = document.getElementById('app');
  const toastEl = document.getElementById('toast');
  const money = new Intl.NumberFormat('ru-RU');
  const tg = window.Telegram?.WebApp || null;

  const STATUS = {
    WAITING_CONFIRMATION: { label: 'Ожидает подтверждения', tone: 'warning' },
    CONFIRMED: { label: 'Подтверждён', tone: '' },
    PAYMENT_PENDING: { label: 'Ожидает оплаты', tone: 'warning' },
    PAID: { label: 'Оплачен', tone: 'success' },
    SENT_TO_STORE: { label: 'Передан в точку', tone: '' },
    IN_PRODUCTION: { label: 'Готовится', tone: '' },
    READY: { label: 'Готов к получению', tone: 'success' },
    COURIER_ORDERED: { label: 'Курьер вызван', tone: '' },
    COURIER_PICKED_UP: { label: 'Передан курьеру', tone: '' },
    DELIVERED: { label: 'Доставлен', tone: 'success' },
    REFUND_PENDING: { label: 'Возврат согласуется', tone: 'warning' },
    REFUNDED: { label: 'Возвращён', tone: '' },
    COMPLETED: { label: 'Выполнен', tone: 'success' },
    CANCELLED: { label: 'Отменён', tone: 'danger' },
    EXPIRED_UNCLAIMED: { label: 'Срок хранения истёк', tone: 'danger' }
  };

  const state = {
    route: 'catalog',
    previousRoute: null,
    category: 'set',
    berryType: 'all',
    productId: null,
    variantId: null,
    quantity: 1,
    berryAddon: '',
    inscription: false,
    inscriptionText: '',
    checkout: {
      fulfilment: 'pickup',
      storeId: 'discovery',
      date: todayISO(),
      time: '',
      customerName: '',
      customerPhone: '',
      deliveryAddress: '',
      recipientName: '',
      recipientPhone: '',
      comment: '',
      consent: false
    },
    currentOrderId: null
  };

  initTelegram();
  hydrateCustomer();
  applyInitialHash();
  openFromStartParam();
  render();
  refreshOrders();
  setInterval(() => { if (!document.hidden) { if (['orders','order','success'].includes(state.route))refreshOrders(); if(state.route==='checkout'){slotCache.clear();refreshCheckoutData();} } }, 15000);

  document.addEventListener('click', handleClick);
  document.addEventListener('change', handleChange);
  document.addEventListener('input', handleInput);
  window.addEventListener('storage', () => {
    if (state.route === 'orders' || state.route === 'order') render();
  });
  window.addEventListener('hashchange', handleHashRoute);

  function initTelegram() {
    if (!tg) return;
    try {
      tg.ready();
      tg.expand();
      tg.setHeaderColor?.('#f8f1e8');
      tg.setBackgroundColor?.('#f3eadf');
      tg.setBottomBarColor?.('#fffaf3');
      tg.enableVerticalSwipes?.();
    } catch (error) {
      console.warn('Telegram WebApp init failed', error);
    }
  }


  function applyInitialHash() {
    const hash = location.hash.replace(/^#/, '');
    if (['catalog', 'orders', 'contacts'].includes(hash)) state.route = hash;
  }

  function openFromStartParam() {
    const params = new URLSearchParams(location.search);
    const hash = new URLSearchParams(location.hash.replace(/^#/, ''));
    const start = tg?.initDataUnsafe?.start_param || params.get('tgWebAppStartParam') || params.get('product') || hash.get('product');
    if (!start) return;
    const normalized = String(start).replace(/^product[-_:]/i, '').toUpperCase();
    const product = catalog.products.find(p => p.id.toUpperCase() === normalized);
    if (product) openProduct(product.id, false);
  }

  function handleHashRoute() {
    const hash = location.hash.replace(/^#/, '');
    if (hash === 'catalog') navigate('catalog', false);
    if (hash === 'orders') navigate('orders', false);
    if (hash === 'contacts') navigate('contacts', false);
  }

  function hydrateCustomer() {
    const saved = {};
    const user = tg?.initDataUnsafe?.user;
    const fullName = [user?.first_name, user?.last_name].filter(Boolean).join(' ');
    state.checkout.customerName = saved.name || fullName || '';
    state.checkout.customerPhone = saved.phone || '';
  }

  function render() {
    const focused=document.activeElement?.id; const selectionStart=document.activeElement?.selectionStart; const selectionEnd=document.activeElement?.selectionEnd;
    switch (state.route) {
      case 'catalog': renderCatalog(); break;
      case 'product': renderProduct(); break;
      case 'checkout': renderCheckout(); break;
      case 'success': renderSuccess(); break;
      case 'orders': renderOrders(); break;
      case 'order': renderOrderDetail(); break;
      case 'contacts': renderContacts(); break;
      default: renderCatalog();
    }
    if(focused){const field=document.getElementById(focused);field?.focus({preventScroll:true});if(field?.setSelectionRange&&typeof selectionStart==='number'){try{field.setSelectionRange(selectionStart,selectionEnd);}catch{}}}
    syncTelegramControls();
    refreshCheckoutData();
  }

  function renderHeader({ back = false } = {}) {
    return `
      ${back ? `<button class="top-back" data-action="back" type="button">← Назад</button>` : ''}
      <header class="app-header">
        <button class="brand" data-action="go-catalog" type="button" style="border:0;background:transparent;padding:0;text-align:left">
          <img class="brand-logo" src="assets/logo.webp" alt="Логотип Дели Берри">
          <span class="brand-copy">
            <span class="brand-name">${escapeHTML(catalog.brand.name)}</span>
            <span class="brand-tagline">${escapeHTML(catalog.brand.tagline)}</span>
          </span>
        </button>
        <a class="header-action" href="${catalog.brand.phoneLink}" aria-label="Позвонить" title="${escapeHTML(catalog.brand.phone)}">☎</a>
      </header>${appConfig.paymentMode==='sandbox'?'<div class="notice warning">Тестовый режим оплаты. Не используйте реальные платёжные данные.</div>':''}`;
  }

  function renderCatalog() {
    const products = catalog.products.filter(product => {
      if (product.kind !== state.category) return false;
      if (state.berryType === 'all') return true;
      return product.variants.some(v => v.type === state.berryType);
    });

    app.innerHTML = `
      ${renderHeader()}
      <section class="hero">
        <div class="hero-kicker">✓ Самовывоз и курьерская доставка</div>
        <h1>Клубника в шоколаде, которую удобно выбрать</h1>
        <p>Наборы и букеты из свежей или сублимированной клубники. Выберите вариант, точку, дату и время — оператор проверит заказ и свяжется с вами.</p>
        <div class="hero-facts">
          <span class="fact-chip">🍓 Свежие наборы 20–30 минут</span>
          <span class="fact-chip">💐 Свежие букеты 30–60 минут</span>
          <span class="fact-chip">✨ Сублимированные в наличии</span>
        </div>
      </section>

      <section class="section">
        <div class="section-head">
          <div>
            <h2 class="section-title">Каталог</h2>
            <p class="section-subtitle">Цена меняется вместе с выбранным типом клубники.</p>
          </div>
        </div>
        <div class="segmented" role="tablist" aria-label="Категория">
          ${segment('set', 'Наборы', state.category)}
          ${segment('bouquet', 'Букеты', state.category)}
        </div>
        <div class="segmented" role="tablist" aria-label="Тип клубники">
          ${typeSegment('all', 'Все')}
          ${typeSegment('fresh', 'Свежая')}
          ${typeSegment('freeze_dried', 'Сублимированная')}
        </div>
      </section>

      <section class="section">
        <div class="catalog-grid">
          ${products.length ? products.map(renderProductCard).join('') : `<div class="empty-state">В выбранной категории пока нет товаров.</div>`}
        </div>
      </section>

      ${renderBottomNav('catalog')}`;
  }

  function segment(value, label, active) {
    return `<button class="segment-button ${value === active ? 'active' : ''}" data-action="set-category" data-value="${value}" type="button">${label}</button>`;
  }

  function typeSegment(value, label) {
    return `<button class="segment-button ${value === state.berryType ? 'active' : ''}" data-action="set-berry-type" data-value="${value}" type="button">${label}</button>`;
  }

  function renderProductCard(product) {
    const visibleVariants = state.berryType === 'all' ? product.variants : product.variants.filter(v => v.type === state.berryType);
    const minPrice = Math.min(...visibleVariants.map(v => v.price));
    const maxPrice = Math.max(...visibleVariants.map(v => v.price));
    const prep = [...new Set(visibleVariants.map(v => v.prepText))];
    const priceLabel = minPrice === maxPrice ? `${fmt(minPrice)} ₽` : `от ${fmt(minPrice)} ₽`;
    return `
      <article class="product-card" data-action="open-product" data-product-id="${product.id}" tabindex="0" role="button" aria-label="${escapeAttr(product.title)}">
        <div class="product-photo-wrap">
          <img class="product-photo" src="${product.thumbnail}" alt="${escapeAttr(product.title)}" loading="lazy">
          <div class="card-badges">
            ${product.badges.slice(0, 2).map((b, i) => `<span class="badge ${i === 1 ? 'mint' : ''}">${escapeHTML(b)}</span>`).join('')}
          </div>
        </div>
        <div class="card-body">
          <h3 class="card-title">${escapeHTML(product.title)}</h3>
          <p class="card-subtitle">${escapeHTML(prep.join(' · '))}</p>
          <div class="card-footer">
            <div class="price"><small>${visibleVariants.length > 1 ? `${visibleVariants.length} варианта` : visibleVariants[0].label}</small>${priceLabel}</div>
            <span class="card-arrow">→</span>
          </div>
        </div>
      </article>`;
  }

  function renderProduct() {
    const product = getProduct();
    const variant = getVariant();
    if (!product || !variant) return navigate('catalog');
    normalizeAddOns(variant);
    const total = calculateTotal();
    const storageText = variant.type === 'fresh' ? catalog.storage.fresh : catalog.storage.freezeDried;
    const included = Boolean(variant.includedAddOnGroup);

    app.innerHTML = `
      ${renderHeader({ back: true })}
      <main class="page-card detail-layout">
        <img class="detail-image" src="${product.image}" alt="${escapeAttr(product.title)}">
        <div class="detail-content">
          <div class="detail-kicker">${product.kind === 'set' ? 'Набор' : 'Букет'}</div>
          <h1 class="detail-title">${escapeHTML(product.title)}</h1>
          <p class="detail-description">${escapeHTML(product.description)}</p>

          <div class="form-section">
            <h2 class="form-title">Выберите вариант</h2>
            <div class="option-list">
              ${product.variants.map(v => `
                <label class="option-card ${v.id === variant.id ? 'selected' : ''}">
                  <input type="radio" name="variant" value="${v.id}" data-bind="variant" ${v.id === variant.id ? 'checked' : ''}>
                  <span>
                    <span class="option-name">${escapeHTML(v.label)}</span>
                    <span class="option-note">${escapeHTML(v.prepText)}${v.note ? ` · ${escapeHTML(v.note)}` : ''}</span>
                  </span>
                  <span class="option-price">${fmt(v.price)} ₽</span>
                </label>`).join('')}
            </div>
          </div>

          ${variant.addOns ? `
          <div class="form-section">
            <h2 class="form-title">Оформление</h2>
            <p class="form-note">Можно выбрать один вид целой ягоды. Голубика и малина одновременно не добавляются автоматически.</p>
            ${included ? `<div class="notice berry"><span>✓</span><span>Ягодное оформление уже включено в стоимость варианта A06.</span></div>` : `
              <div class="option-list">
                ${berryAddonOption('', 'Без дополнительной ягоды', 0)}
                ${berryAddonOption('whole-blueberry', 'Целая голубика', 200)}
                ${berryAddonOption('whole-raspberry', 'Целая малина', 200)}
              </div>`}
            <div style="height:8px"></div>
            <label class="checkbox-card ${state.inscription ? 'checked' : ''}">
              <input type="checkbox" data-bind="inscription" ${state.inscription ? 'checked' : ''}>
              <span>
                <span class="option-name">Шоколадная надпись</span>
                <span class="option-note">Текст проверит оператор перед оплатой.</span>
              </span>
              <span class="option-price">+250 ₽</span>
            </label>
            ${state.inscription ? `<div class="field" style="margin-top:9px"><label for="inscriptionText">Текст надписи</label><input id="inscriptionText" class="input" maxlength="40" data-bind="inscriptionText" value="${escapeAttr(state.inscriptionText)}" placeholder="Например: С днём рождения!"></div>` : ''}
          </div>` : ''}

          <div class="form-section">
            <h2 class="form-title">О товаре</h2>
            <div class="info-row"><div class="info-icon">⏱</div><div><div class="info-label">Готовность</div><div class="info-value">${escapeHTML(variant.prepText)}</div></div></div>
            <div class="info-row"><div class="info-icon">❄</div><div><div class="info-label">Хранение</div><div class="info-value">${escapeHTML(storageText)}</div></div></div>
            <div class="info-row"><div class="info-icon">📍</div><div><div class="info-label">Получение</div><div class="info-value">Самовывоз из Discovery или Zеленопарка либо доставка сторонним курьерским сервисом.</div></div></div>
          </div>

          <div class="quantity-row">
            <div><div class="option-name">Количество</div><div class="option-note">Одинаковая комплектация</div></div>
            <div class="quantity-control">
              <button class="qty-button" data-action="qty-minus" type="button" aria-label="Уменьшить">−</button>
              <div class="qty-value">${state.quantity}</div>
              <button class="qty-button" data-action="qty-plus" type="button" aria-label="Увеличить">+</button>
            </div>
          </div>

          <div class="sticky-summary">
            <div class="summary-line"><span class="summary-label">Итого за товар</span><span class="summary-total">${fmt(total)} ₽</span></div>
            <div class="summary-meta">Доставка оплачивается отдельно по фактическому тарифу курьерского сервиса.</div>
            <button class="button primary block" data-action="checkout" type="button" ${total === null ? 'disabled' : ''}>Оформить заказ</button>
          </div>
        </div>
      </main>`;
  }

  function berryAddonOption(id, label, price) {
    const selected = state.berryAddon === id;
    return `
      <label class="option-card ${selected ? 'selected' : ''}">
        <input type="radio" name="berryAddon" value="${id}" data-bind="berryAddon" ${selected ? 'checked' : ''}>
        <span><span class="option-name">${label}</span></span>
        <span class="option-price">${price ? `+${fmt(price)} ₽` : '0 ₽'}</span>
      </label>`;
  }

  function renderCheckout() {
    const product = getProduct();
    const variant = getVariant();
    if (!product || !variant) return navigate('catalog');
    ensureValidTime();
    const total = calculateTotal();
    const slots = getTimeSlots(variant.prepMinutes, state.checkout.date);
    const selectedStore = catalog.stores.find(s => s.id === state.checkout.storeId) || catalog.stores[0];
    const addOnLines = selectedAddOns();

    app.innerHTML = `
      ${renderHeader({ back: true })}
      <main class="checkout-layout">
        <section class="checkout-card">
          <h1 class="section-title">Оформление заказа</h1>
          <p class="section-subtitle">${paymentNotice}</p>

          <div class="form-section">
            <h2 class="form-title">Как получить</h2>
            <div class="segmented">
              <button class="segment-button ${state.checkout.fulfilment === 'pickup' ? 'active' : ''}" data-action="set-fulfilment" data-value="pickup" type="button">Самовывоз</button>
              <button class="segment-button ${state.checkout.fulfilment === 'courier' ? 'active' : ''}" data-action="set-fulfilment" data-value="courier" type="button">Курьер</button>
            </div>
            ${state.checkout.fulfilment === 'courier' ? `<div class="notice warning" style="margin-top:10px"><span>🚕</span><span>Стоимость доставки не входит в цену товара. Курьера вызывает оператор после готовности заказа; клиент оплачивает фактический тариф сервиса.</span></div>` : `<div class="notice" style="margin-top:10px"><span>🛍</span><span>Готовый заказ хранится на выбранной точке до 24 часов, но не дольше срока годности.</span></div>`}
          </div>

          <div class="form-section">
            <h2 class="form-title">Точка приготовления</h2>
            <div class="option-list">
              ${catalog.stores.map(store => `
                <label class="option-card ${state.checkout.storeId === store.id ? 'selected' : ''}">
                  <input type="radio" name="store" value="${store.id}" data-bind="storeId" ${state.checkout.storeId === store.id ? 'checked' : ''}>
                  <span><span class="option-name">${escapeHTML(store.shortName)}</span><span class="option-note">${escapeHTML(store.address)} · ${escapeHTML(store.hours)}</span></span>
                  <span class="option-price">→</span>
                </label>`).join('')}
            </div>
          </div>

          <div class="form-section">
            <h2 class="form-title">Дата и время по Москве</h2>
            <div class="field-grid two">
              <div class="field"><label for="orderDate">Дата</label><input id="orderDate" class="input" type="date" min="${todayISO()}" data-bind="date" value="${escapeAttr(state.checkout.date)}"></div>
              <div class="field"><label for="orderTime">${state.checkout.fulfilment === 'courier' ? 'Желаемое время' : 'Время получения'}</label>
                <select id="orderTime" class="select" data-bind="time">
                  <option value="">Выберите</option>
                  ${slots.map(slot => `<option value="${slot}" ${state.checkout.time === slot ? 'selected' : ''}>${slot}</option>`).join('')}
                </select>
              </div>
            </div>
            ${slots.length ? '' : `<div class="notice warning" style="margin-top:9px"><span>!</span><span>${!slotCache.has(slotKey()) ? 'Проверяем доступное время…' : escapeHTML(slotCache.get(slotKey()).error) || 'На выбранную дату нет доступного времени. Выберите другой день.'}</span></div>`}
          </div>

          ${state.checkout.fulfilment === 'courier' ? `
          <div class="form-section">
            <h2 class="form-title">Доставка</h2>
            <div class="field-grid">
              <div class="field"><label for="deliveryAddress">Адрес доставки *</label><input id="deliveryAddress" class="input" data-bind="deliveryAddress" value="${escapeAttr(state.checkout.deliveryAddress)}" placeholder="Город, улица, дом, квартира/офис"></div>
              <div class="field-grid two">
                <div class="field"><label for="recipientName">Получатель</label><input id="recipientName" class="input" data-bind="recipientName" value="${escapeAttr(state.checkout.recipientName)}" placeholder="Если не вы"></div>
                <div class="field"><label for="recipientPhone">Телефон получателя</label><input id="recipientPhone" class="input" inputmode="tel" data-bind="recipientPhone" value="${escapeAttr(state.checkout.recipientPhone)}" placeholder="+7 999 000-00-00"></div>
              </div>
            </div>
          </div>` : ''}

          <div class="form-section">
            <h2 class="form-title">Ваши контакты</h2>
            <div class="field-grid two">
              <div class="field"><label for="customerName">Имя *</label><input id="customerName" class="input" data-bind="customerName" value="${escapeAttr(state.checkout.customerName)}" autocomplete="name" placeholder="Как к вам обращаться"></div>
              <div class="field"><label for="customerPhone">Телефон *</label><input id="customerPhone" class="input" inputmode="tel" data-bind="customerPhone" value="${escapeAttr(state.checkout.customerPhone)}" autocomplete="tel" placeholder="+7 999 000-00-00"></div>
            </div>
            <div class="field" style="margin-top:11px"><label for="comment">Комментарий</label><textarea id="comment" class="textarea" data-bind="comment" maxlength="500" placeholder="Пожелания по заказу или ориентир для курьера">${escapeHTML(state.checkout.comment)}</textarea></div>
          </div>

          <div class="form-section">
            <label class="checkbox-card ${state.checkout.consent ? 'checked' : ''}">
              <input type="checkbox" data-bind="consent" ${state.checkout.consent ? 'checked' : ''}>
              <span><span class="option-name">Согласен с условиями заказа</span><span class="option-note">И обработкой контактных данных для выполнения заказа. <a href="${escapeAttr(appConfig.termsUrl)}" target="_blank" rel="noopener">Условия заказа</a> · <a href="${escapeAttr(appConfig.privacyUrl)}" target="_blank" rel="noopener">Политика обработки данных</a>.</span></span>
            </label>
          </div>
        </section>

        <aside class="checkout-card checkout-summary">
          <div class="checkout-product">
            <img src="${product.thumbnail}" alt="">
            <div><div class="checkout-product-title">${escapeHTML(product.title)}</div><div class="checkout-product-meta">${escapeHTML(variant.label)} · ${state.quantity} шт.</div></div>
          </div>
          <div class="order-breakdown">
            <div class="breakdown-line"><span>Товар</span><strong>${fmt(variant.price * state.quantity)} ₽</strong></div>
            ${addOnLines.map(line => `<div class="breakdown-line muted"><span>${escapeHTML(line.name)}</span><span>+${fmt(line.price * state.quantity)} ₽</span></div>`).join('')}
            <div class="breakdown-line muted"><span>${state.checkout.fulfilment === 'courier' ? 'Доставка' : 'Получение'}</span><span>${state.checkout.fulfilment === 'courier' ? 'оплачивается отдельно' : '0 ₽'}</span></div>
            <div class="breakdown-line total"><span>Итого</span><span>${fmt(total)} ₽</span></div>
          </div>
          <div class="notice berry" style="margin-top:14px"><span>₽</span><span>${paymentNotice}</span></div>
          <button class="button primary block" data-action="submit-order" type="button" ${submitting || total === null || !state.checkout.time ? 'disabled' : ''} style="margin-top:12px">${submitting ? 'Отправляем…' : 'Отправить заказ'}</button>
          <a class="button ghost block" href="${catalog.brand.phoneLink}" style="margin-top:8px">Позвонить ${escapeHTML(catalog.brand.phone)}</a>
        </aside>
      </main>`;
  }

  function renderSuccess() {
    const order = findOrder(state.currentOrderId);
    if (!order) return navigate('orders');
    app.innerHTML = `
      ${renderHeader()}
      <main class="success-card">
        <div class="success-icon">✓</div>
        <h1>Заказ принят</h1>
        <div class="order-number">${escapeHTML(order.id)}</div>
        <p>Оператор проверит комплектацию, выбранное время и точку, после чего свяжется с вами по номеру <strong>${escapeHTML(order.customer.phone)}</strong>.</p>
        ${renderTimeline(order)}
        <div class="notice berry"><span>Я</span><span>${paymentNotice}</span></div>
        <div class="button-row" style="margin-top:14px">
          <button class="button secondary" data-action="view-order" data-order-id="${order.id}" type="button">Статус заказа</button>
          <button class="button primary" data-action="go-catalog" type="button">В каталог</button>
        </div>
      </main>`;
  }

  function renderOrders() {
    const orders = getOrders().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    app.innerHTML = `
      ${renderHeader()}
      <section class="section">
        <div class="section-head"><div><h1 class="section-title">Мои заказы</h1><p class="section-subtitle">Статус обновляется после действий оператора.</p></div></div>
        <div class="order-list">${orderError ? `<div class="notice warning">${escapeHTML(orderError)}</div>` : ''}
          ${orders.length ? orders.map(renderOrderCard).join('') : `<div class="empty-state"><div style="font-size:32px;margin-bottom:8px">🍓</div>У вас пока нет заказов.<div style="margin-top:12px"><button class="button primary" data-action="go-catalog">Открыть каталог</button></div></div>`}
        </div>
        ${nextBefore?'<button class="button secondary block" data-action="more-orders">Показать более ранние заказы</button>':''}
      </section>
      ${renderBottomNav('orders')}`;
  }

  function renderOrderCard(order) {
    const status = STATUS[order.status] || STATUS.WAITING_CONFIRMATION;
    return `
      <article class="order-card" data-action="view-order" data-order-id="${order.id}">
        <div class="order-card-head"><div><div class="order-card-number">${escapeHTML(order.id)}</div><div class="order-card-date">${formatDateTime(order.createdAt)}</div></div><span class="status-pill ${status.tone}">${status.label}</span></div>
        <div class="order-card-product">${escapeHTML(order.product.title)}</div>
        <div class="order-card-meta">${escapeHTML(order.variant.label)} · ${order.quantity} шт. · ${fmt(order.total)} ₽<br>${escapeHTML(order.fulfilment.label)} · ${escapeHTML(order.schedule.date)} ${escapeHTML(order.schedule.time)}</div>
      </article>`;
  }

  function renderOrderDetail() {
    const order = findOrder(state.currentOrderId);
    if (!order) return navigate('orders');
    const status = STATUS[order.status] || STATUS.WAITING_CONFIRMATION;
    const paymentReady = order.status === 'PAYMENT_PENDING' && order.payment?.status === 'PENDING' && order.payment?.url;
    app.innerHTML = `
      ${renderHeader({ back: true })}
      <main class="page-card">
        <div class="detail-content">
          <div class="detail-kicker">Заказ ${escapeHTML(order.id)}</div>
          <h1 class="detail-title">${escapeHTML(order.product.title)}</h1>
          <div style="margin-top:12px"><span class="status-pill ${status.tone}">${status.label}</span></div>
          ${renderTimeline(order)}
          <div class="form-section">
            <h2 class="form-title">Детали</h2>
            <div class="info-row"><div class="info-icon">🍓</div><div><div class="info-label">Товар</div><div class="info-value">${escapeHTML(order.variant.label)}, ${order.quantity} шт. — ${fmt(order.total)} ₽</div></div></div>
            <div class="info-row"><div class="info-icon">📅</div><div><div class="info-label">Дата и время</div><div class="info-value">${escapeHTML(order.schedule.date)} в ${escapeHTML(order.schedule.time)}</div></div></div>
            <div class="info-row"><div class="info-icon">📍</div><div><div class="info-label">Получение</div><div class="info-value">${escapeHTML(order.fulfilment.label)} · ${escapeHTML(order.store.name)}<br>${escapeHTML(order.store.address)}</div></div></div>
            <div class="info-row"><div class="info-icon">☎</div><div><div class="info-label">Связь</div><div class="info-value">${escapeHTML(catalog.brand.phone)}</div></div></div>
          </div>
          ${paymentReady ? `<a class="button primary block" href="${escapeAttr(order.payment.url)}" target="_blank" rel="noopener">Оплатить Яндекс Пэй</a>` : (['WAITING_CONFIRMATION','CONFIRMED','PAYMENT_PENDING'].includes(order.status) ? `<div class="notice">${paymentNotice}</div>` : '')}
          <a class="button ghost block" href="${catalog.brand.phoneLink}" style="margin-top:8px">Позвонить оператору</a>
        </div>
      </main>`;
  }

  function renderTimeline(order) {
    if (['CANCELLED','REFUNDED','REFUND_PENDING','EXPIRED_UNCLAIMED'].includes(order.status)) return `<div class="notice warning">${escapeHTML(STATUS[order.status].label)}. Подробности уточните у оператора.</div>`;
    const steps = [
      { key: 'WAITING_CONFIRMATION', title: 'Заказ получен', note: 'Оператор проверяет комплектацию, дату и точку.' },
      { key: 'PAYMENT_PENDING', title: 'Подтверждение и оплата', note: paymentNotice },
      { key: 'IN_PRODUCTION', title: 'Подготовка', note: 'Заказ передан выбранной точке.' },
      { key: 'READY', title: order.fulfilment?.type === 'courier' ? 'Готов и ожидает курьера' : 'Готов к получению', note: order.fulfilment?.type === 'courier' ? 'Оператор организует передачу стороннему курьеру.' : 'Хранение до 24 часов, в пределах срока годности.' },
      { key: 'COMPLETED', title: order.fulfilment?.type === 'courier' ? 'Доставлен' : 'Выдан', note: 'Заказ завершён.' }
    ];
    const rank = statusRank(order.status);
    return `<div class="timeline">${steps.map((step, index) => {
      const cls = index < rank ? 'done' : index === rank ? 'active' : '';
      return `<div class="timeline-item ${cls}"><div class="timeline-dot">${index < rank ? '✓' : index + 1}</div><div><div class="timeline-title">${step.title}</div><div class="timeline-note">${step.note}</div></div></div>`;
    }).join('')}</div>`;
  }

  function statusRank(status) {
    const map = {
      WAITING_CONFIRMATION: 0,
      CONFIRMED: 1,
      PAYMENT_PENDING: 1,
      PAID: 2,
      SENT_TO_STORE: 2,
      IN_PRODUCTION: 2,
      READY: 3,
      COURIER_ORDERED: 3,
      COURIER_PICKED_UP: 3,
      DELIVERED: 4,
      COMPLETED: 4
    };
    return map[status] ?? 0;
  }

  function renderContacts() {
    app.innerHTML = `
      ${renderHeader()}
      <section class="section">
        <div class="section-head"><div><h1 class="section-title">Контакты и точки</h1><p class="section-subtitle">Один номер для заказов, звонков и сопровождения.</p></div></div>
        <div class="contact-card" style="margin-bottom:12px">
          <h3>${escapeHTML(catalog.brand.phone)}</h3>
          <p>Оператор проверяет все заказы и передаёт их выбранной точке.</p>
          <div class="contact-actions"><a class="button primary" href="${catalog.brand.phoneLink}">Позвонить</a><button class="button secondary" data-action="copy-phone" type="button">Скопировать номер</button></div>
        </div>
        <div class="contact-grid">
          ${catalog.stores.map(store => `<article class="contact-card"><h3>${escapeHTML(store.name)}</h3><p>${escapeHTML(store.address)}<br>${escapeHTML(store.hours)}</p><div class="contact-actions"><a class="button secondary" href="${escapeAttr(store.mapsUrl)}" target="_blank" rel="noopener">Яндекс Карты</a><a class="button ghost" href="${catalog.brand.phoneLink}">Позвонить</a></div></article>`).join('')}
        </div>
      </section>
      <section class="section">
        <div class="contact-card"><h3>Продавец</h3><p>${escapeHTML(catalog.seller.legalName)}<br>ИНН ${catalog.seller.inn} · ОГРНИП ${catalog.seller.ogrnip}<br>Адрес регистрации: ${escapeHTML(catalog.seller.registrationAddress)}</p><div class="contact-actions"><a class="button ghost" href="legal.html">Условия и реквизиты</a></div></div>
      </section>
      ${renderBottomNav('contacts')}`;
  }

  function renderBottomNav(active) {
    return `<nav class="bottom-nav" aria-label="Навигация">
      ${navButton('catalog', '⌂', 'Каталог', active)}
      ${navButton('orders', '▤', 'Заказы', active)}
      ${navButton('contacts', '☎', 'Контакты', active)}
    </nav>`;
  }

  function navButton(route, icon, label, active) {
    return `<button class="nav-button ${route === active ? 'active' : ''}" data-action="navigate" data-route="${route}" type="button"><span class="nav-icon">${icon}</span><span>${label}</span></button>`;
  }

  function handleClick(event) {
    const target = event.target.closest('[data-action]');
    if (!target) return;
    const action = target.dataset.action;
    switch (action) {
      case 'set-category': state.category = target.dataset.value; haptic('selection'); render(); break;
      case 'set-berry-type': state.berryType = target.dataset.value; haptic('selection'); render(); break;
      case 'open-product': openProduct(target.dataset.productId); break;
      case 'qty-minus': state.quantity = Math.max(1, state.quantity - 1); render(); break;
      case 'qty-plus': state.quantity = Math.min(10, state.quantity + 1); render(); break;
      case 'checkout': navigate('checkout'); break;
      case 'set-fulfilment': state.checkout.fulfilment = target.dataset.value; state.checkout.time = ''; haptic('selection'); render(); break;
      case 'submit-order': submitOrder(); break;
      case 'go-catalog': resetSelection(); navigate('catalog'); break;
      case 'navigate': navigate(target.dataset.route); break;
      case 'back': goBack(); break;
      case 'more-orders': refreshOrders(true); break;
      case 'view-order': state.currentOrderId = target.dataset.orderId; navigate('order'); break;
      case 'copy-phone': copyText(catalog.brand.phone, 'Номер скопирован'); break;
    }
  }

  function handleChange(event) {
    const bind = event.target.dataset.bind;
    if (!bind) return;
    const el = event.target;
    switch (bind) {
      case 'variant':
        state.variantId = el.value;
        state.berryAddon = '';
        normalizeAddOns(getVariant());
        haptic('selection');
        render();
        break;
      case 'berryAddon': state.berryAddon = el.value; haptic('selection'); render(); break;
      case 'inscription': state.inscription = el.checked; if (!el.checked) state.inscriptionText = ''; render(); break;
      case 'storeId': state.checkout.storeId = el.value; render(); break;
      case 'date': state.checkout.date = el.value || todayISO(); state.checkout.time = ''; render(); break;
      case 'time': state.checkout.time = el.value; render(); break;
      case 'consent': state.checkout.consent = el.checked; render(); break;
    }
  }

  function handleInput(event) {
    const bind = event.target.dataset.bind;
    if (!bind) return;
    const value = event.target.value;
    if (Object.prototype.hasOwnProperty.call(state.checkout, bind)) state.checkout[bind] = value;
    if (bind === 'inscriptionText') {state.inscriptionText = value;clearTimeout(handleInput.quoteTimer);handleInput.quoteTimer=setTimeout(refreshCheckoutData,400);}
  }

  function openProduct(productId, push = true) {
    const product = catalog.products.find(p => p.id === productId);
    if (!product) return;
    state.productId = productId;
    const preferred = state.berryType !== 'all' ? product.variants.find(v => v.type === state.berryType) : null;
    state.variantId = (preferred || product.variants[0]).id;
    state.quantity = 1;
    state.berryAddon = '';
    state.inscription = false;
    state.inscriptionText = '';
    navigate('product', push);
  }

  function resetSelection() {
    state.productId = null;
    state.variantId = null;
    state.quantity = 1;
    state.berryAddon = '';
    state.inscription = false;
    state.inscriptionText = '';
  }

  function navigate(route, push = true) {
    state.previousRoute = state.route;
    state.route = route;
    if (push && ['catalog', 'orders', 'contacts'].includes(route)) history.replaceState(null, '', `#${route}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    render();
    if (['orders','order'].includes(route)) refreshOrders();
  }

  function goBack() {
    if (state.route === 'checkout') return navigate('product');
    if (state.route === 'product') return navigate('catalog');
    if (state.route === 'order') return navigate('orders');
    navigate(state.previousRoute || 'catalog');
  }

  function getProduct() { return catalog.products.find(p => p.id === state.productId); }
  function getVariant() {
    const product = getProduct();
    return product?.variants.find(v => v.id === state.variantId) || product?.variants[0];
  }

  function normalizeAddOns(variant) {
    if (!variant?.addOns) {
      state.berryAddon = '';
      state.inscription = false;
      state.inscriptionText = '';
    }
    if (variant?.includedAddOnGroup) state.berryAddon = '';
  }

  function selectedAddOns() {
    const variant = getVariant();
    if (!variant?.addOns) return [];
    const lines = [];
    if (!variant.includedAddOnGroup && state.berryAddon) {
      const item = catalog.pricing.addOns.find(a => a.id === state.berryAddon);
      if (item) lines.push(item);
    }
    if (state.inscription) {
      const item = catalog.pricing.addOns.find(a => a.id === 'chocolate-inscription');
      if (item) lines.push({ ...item, name: state.inscriptionText.trim() ? `${item.name}: «${state.inscriptionText.trim()}»` : item.name });
    }
    return lines;
  }

  function calculateTotal() { return quoteCache.get(quoteKey()) ?? null; }
  function getTimeSlots() { return slotCache.get(slotKey())?.slots || []; }

  function ensureValidTime() {
    const variant = getVariant();
    if (!variant) return;
    const slots = getTimeSlots(variant.prepMinutes, state.checkout.date);
    if (!slots.includes(state.checkout.time)) state.checkout.time = '';
  }

  async function submitOrder() {
    if (submitting) return;
    const errors = validateOrder();
    if (errors.length) { toast(errors[0]); return; }
    const c = state.checkout;
    const order = {...selection(),store:{id:c.storeId},schedule:{date:c.date,time:c.time},
      customer:{name:c.customerName.trim(),phone:normalizePhone(c.customerPhone)},
      fulfilment:{type:c.fulfilment,deliveryAddress:c.deliveryAddress.trim()},
      recipient:{name:c.recipientName.trim(),phone:normalizePhone(c.recipientPhone)},comment:c.comment.trim(),consent:c.consent};
    submitting=true; render();
    try {
      const saved=await saveOrder(order); state.currentOrderId=saved.id;
      haptic('success'); navigate('success');
    } catch(error) { haptic('error');toast(error.message); }
    finally { submitting=false;if(state.route==='checkout')render(); }
  }

  function validateOrder() {
    document.querySelectorAll('.invalid').forEach(el => el.classList.remove('invalid'));
    const errors = [];
    const checkout = state.checkout;
    if (!checkout.date) errors.push('Выберите дату.');
    if (!checkout.time) { errors.push('Выберите время.'); document.getElementById('orderTime')?.classList.add('invalid'); }
    if (!checkout.customerName.trim()) { errors.push('Укажите имя.'); document.getElementById('customerName')?.classList.add('invalid'); }
    if (!isValidPhone(checkout.customerPhone)) { errors.push('Укажите корректный телефон.'); document.getElementById('customerPhone')?.classList.add('invalid'); }
    if (checkout.fulfilment === 'courier' && !checkout.deliveryAddress.trim()) { errors.push('Укажите адрес доставки.'); document.getElementById('deliveryAddress')?.classList.add('invalid'); }
    if (checkout.recipientPhone && !isValidPhone(checkout.recipientPhone)) { errors.push('Проверьте телефон получателя.'); document.getElementById('recipientPhone')?.classList.add('invalid'); }
    if (state.inscription && !state.inscriptionText.trim()) errors.push('Укажите текст шоколадной надписи.');
    if (!checkout.consent) errors.push('Подтвердите согласие с условиями заказа.');
    return errors;
  }

  async function saveOrder(order) {
    const body=JSON.stringify(order);
    const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(body));
    const signature=Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('');
    let request;
    try { request=JSON.parse(sessionStorage.getItem('deliBerry.pending.v2')); } catch {}
    if(request?.signature!==signature) request={signature,key:crypto.randomUUID()};
    sessionStorage.setItem('deliBerry.pending.v2',JSON.stringify(request));
    const result=await api('/api/orders',{method:'POST',headers:{'Idempotency-Key':request.key},body});
    if(!result.order?.id)throw new Error('Сервер не подтвердил заказ. Повторите отправку.');
    const index=serverOrders.findIndex(o=>o.id===result.order.id);
    if(index<0)serverOrders.unshift(result.order);else serverOrders[index]=result.order;
    sessionStorage.removeItem('deliBerry.pending.v2');
    return result.order;
  }
  function getOrders() { return [...serverOrders]; }
  function findOrder(id) { return serverOrders.find(order=>order.id===id); }

  function syncTelegramControls() {
    if (!tg) return;
    try {
      tg.BackButton.offClick?.(goBack);
      if (['product', 'checkout', 'order'].includes(state.route)) {
        tg.BackButton.show();
        tg.BackButton.onClick(goBack);
      } else tg.BackButton.hide();

      tg.MainButton.hide();
      tg.MainButton.offClick?.(telegramMainAction);
      if (state.route === 'product') {
        tg.MainButton.setParams?.({ text: `ОФОРМИТЬ · ${fmt(calculateTotal())} ₽`, is_visible: true, is_active: calculateTotal() !== null });
        tg.MainButton.onClick(telegramMainAction);
      }
      if (state.route === 'checkout') {
        tg.MainButton.setParams?.({ text: 'ОТПРАВИТЬ ЗАКАЗ', is_visible: true, is_active: !submitting && calculateTotal() !== null && Boolean(state.checkout.time) });
        tg.MainButton.onClick(telegramMainAction);
        tg.enableClosingConfirmation?.();
      } else tg.disableClosingConfirmation?.();
    } catch (error) {
      console.warn('Telegram controls failed', error);
    }
  }

  function telegramMainAction() {
    if (state.route === 'product' && calculateTotal() !== null) navigate('checkout');
    else if (state.route === 'checkout') submitOrder();
  }

  function haptic(type) {
    try {
      if (!tg?.HapticFeedback) return;
      if (type === 'selection') tg.HapticFeedback.selectionChanged();
      else if (['success', 'error', 'warning'].includes(type)) tg.HapticFeedback.notificationOccurred(type);
      else tg.HapticFeedback.impactOccurred('light');
    } catch (_) { /* no-op */ }
  }

  function toast(message) {
    toastEl.textContent = message;
    toastEl.classList.add('show');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => toastEl.classList.remove('show'), 2600);
  }

  async function copyText(text, message) {
    try { await navigator.clipboard.writeText(text); toast(message); }
    catch (_) { toast(text); }
  }

  function todayISO() { return new Date(Date.now()+3*3600000).toISOString().slice(0,10); }

  function isValidPhone(value) { return /^\+7\d{10}$/.test(normalizePhone(value)); }
  function normalizePhone(value = '') {
    const digits = value.replace(/\D/g, '');
    if (digits.length === 11 && digits[0] === '8') return `+7${digits.slice(1)}`;
    if (digits.length === 10) return `+7${digits}`;
    if (digits.length === 11 && digits[0] === '7') return `+${digits}`;
    return value.trim();
  }

  function fmt(value) { return value === null ? '…' : money.format(Number(value || 0)); }
  function formatDateTime(value) {
    try { return new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', timeZone:'Europe/Moscow' }).format(new Date(value)); }
    catch (_) { return value; }
  }

  function escapeHTML(value = '') {
    return String(value).replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
  }
  function escapeAttr(value = '') { return escapeHTML(value).replace(/`/g, '&#96;'); }
})();
