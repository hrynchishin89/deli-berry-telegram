window.DELI_CATALOG = {
  "schema": "deliberry.miniapp.catalog/1.0",
  "updatedAt": "2026-09-29",
  "brand": {
    "name": "Дели Берри",
    "tagline": "Клубника в шоколаде — для подарка и для себя",
    "phone": "+7 (995) 901-47-24",
    "phoneLink": "tel:+79959014724",
    "telegram": "@deliberry_msk"
  },
  "seller": {
    "legalName": "Индивидуальный предприниматель Булгатова Светлана Андреевна",
    "shortName": "ИП Булгатова С. А.",
    "inn": "032621982803",
    "ogrnip": "324030000006409",
    "registrationAddress": "670013, Россия, Республика Бурятия, г. Улан-Удэ, ул. Приречная, д. 8А, кв. 17"
  },
  "stores": [
    {
      "id": "discovery",
      "name": "Дели Берри — ТЦ Discovery",
      "shortName": "Discovery",
      "address": "Москва, ул. Дыбенко, 7/1, ТЦ Discovery",
      "hours": "Ежедневно, 10:00–22:00",
      "mapsUrl": "https://yandex.ru/maps/?text=%D0%94%D0%B5%D0%BB%D0%B8%20%D0%91%D0%B5%D1%80%D1%80%D0%B8%20Discovery%20%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0%20%D0%94%D1%8B%D0%B1%D0%B5%D0%BD%D0%BA%D0%BE%207/1",
      "phone": "+7 (995) 901-47-24"
    },
    {
      "id": "zelenopark",
      "name": "Дели Берри — ТРЦ Zеленопарк",
      "shortName": "Zеленопарк",
      "address": "Московская область, г. о. Солнечногорск, пгт Ржавки, 2-й микрорайон, стр. 20, ТРЦ Zеленопарк",
      "hours": "Ежедневно, 10:00–22:00",
      "mapsUrl": "https://yandex.ru/maps/?text=%D0%94%D0%B5%D0%BB%D0%B8%20%D0%91%D0%B5%D1%80%D1%80%D0%B8%20Z%D0%B5%D0%BB%D0%B5%D0%BD%D0%BE%D0%BF%D0%B0%D1%80%D0%BA%20%D0%A0%D0%B6%D0%B0%D0%B2%D0%BA%D0%B8%202-%D0%B9%20%D0%BC%D0%B8%D0%BA%D1%80%D0%BE%D1%80%D0%B0%D0%B9%D0%BE%D0%BD%20%D1%81%D1%82%D1%80%D0%BE%D0%B5%D0%BD%D0%B8%D0%B5%2020",
      "phone": "+7 (995) 901-47-24"
    }
  ],
  "fulfilment": {
    "pickup": {
      "enabled": true,
      "label": "Самовывоз",
      "holdHours": 24,
      "note": "Готовый заказ хранится на выбранной точке до 24 часов."
    },
    "courier": {
      "enabled": true,
      "label": "Курьерская доставка",
      "note": "Доставку выполняет сторонний курьерский сервис. Стоимость рассчитывается отдельно и оплачивается клиентом. Точное время подтверждает оператор."
    },
    "orderHours": {
      "from": "10:00",
      "to": "22:00",
      "slotMinutes": 15
    }
  },
  "storage": {
    "fresh": "Хранить до 24 часов с момента изготовления при температуре +2…+6 °C в закрытой упаковке. Рекомендуется употребить в день получения. Не замораживать.",
    "freezeDried": "Хранить до 3 месяцев с даты изготовления в закрытой упаковке, в сухом месте при температуре 18±3 °C и относительной влажности не выше 75 %. Точную дату смотрите на упаковке."
  },
  "pricing": {
    "currency": "RUB",
    "addOns": [
      {
        "id": "whole-blueberry",
        "name": "Целая голубика в оформлении",
        "price": 200,
        "group": "whole-berry"
      },
      {
        "id": "whole-raspberry",
        "name": "Целая малина в оформлении",
        "price": 200,
        "group": "whole-berry"
      },
      {
        "id": "chocolate-inscription",
        "name": "Шоколадная надпись",
        "price": 250,
        "group": "inscription"
      }
    ]
  },
  "products": [
    {
      "id": "SET-09",
      "kind": "set",
      "category": "Наборы",
      "title": "Набор из 9 ягод",
      "subtitle": "Клубника в шоколаде",
      "strawberryCount": 9,
      "bananaCount": 0,
      "image": "assets/set-09.webp",
      "thumbnail": "assets/set-09-thumb.webp",
      "badges": [
        "9 ягод"
      ],
      "description": "Компактный подарочный набор. Можно выбрать свежую или сублимированную клубнику.",
      "variants": [
        {
          "id": "SET-09-FRESH",
          "type": "fresh",
          "label": "Свежая клубника",
          "price": 1190,
          "prepText": "Приготовим за 20–30 минут",
          "prepMinutes": 30,
          "addOns": true
        },
        {
          "id": "SET-09-FD",
          "type": "freeze_dried",
          "label": "Сублимированная клубника",
          "price": 890,
          "prepText": "В наличии",
          "prepMinutes": 0,
          "addOns": false
        }
      ]
    },
    {
      "id": "SET-12",
      "kind": "set",
      "category": "Наборы",
      "title": "Набор из 12 ягод",
      "subtitle": "Клубника в шоколаде",
      "strawberryCount": 12,
      "bananaCount": 0,
      "image": "assets/set-12.webp",
      "thumbnail": "assets/set-12-thumb.webp",
      "badges": [
        "12 ягод",
        "Популярный"
      ],
      "description": "Универсальный размер для подарка. Доступны свежая и сублимированная линии, а также подтверждённое оформление A06.",
      "variants": [
        {
          "id": "SET-12-FRESH",
          "type": "fresh",
          "label": "Свежая клубника",
          "price": 1590,
          "prepText": "Приготовим за 20–30 минут",
          "prepMinutes": 30,
          "addOns": true
        },
        {
          "id": "SET-12-A06",
          "type": "fresh",
          "label": "Свежая, оформление A06",
          "price": 1790,
          "prepText": "Приготовим за 20–30 минут",
          "prepMinutes": 30,
          "addOns": true,
          "includedAddOnGroup": "whole-berry",
          "note": "Доплата за ягодное оформление уже включена в цену."
        },
        {
          "id": "SET-12-FD",
          "type": "freeze_dried",
          "label": "Сублимированная клубника",
          "price": 990,
          "prepText": "В наличии",
          "prepMinutes": 0,
          "addOns": false
        }
      ]
    },
    {
      "id": "SET-16",
      "kind": "set",
      "category": "Наборы",
      "title": "Набор из 16 ягод",
      "subtitle": "Клубника в шоколаде",
      "strawberryCount": 16,
      "bananaCount": 0,
      "image": "assets/set-16.webp",
      "thumbnail": "assets/set-16-thumb.webp",
      "badges": [
        "16 ягод"
      ],
      "description": "Большой набор с выбором свежей или сублимированной клубники.",
      "variants": [
        {
          "id": "SET-16-FRESH",
          "type": "fresh",
          "label": "Свежая клубника",
          "price": 1990,
          "prepText": "Приготовим за 20–30 минут",
          "prepMinutes": 30,
          "addOns": true
        },
        {
          "id": "SET-16-FD",
          "type": "freeze_dried",
          "label": "Сублимированная клубника",
          "price": 1250,
          "prepText": "В наличии",
          "prepMinutes": 0,
          "addOns": false
        }
      ]
    },
    {
      "id": "SET-25",
      "kind": "set",
      "category": "Наборы",
      "title": "Набор из 25 ягод",
      "subtitle": "Свежая клубника в шоколаде",
      "strawberryCount": 25,
      "bananaCount": 0,
      "image": "assets/set-25.webp",
      "thumbnail": "assets/set-25-thumb.webp",
      "badges": [
        "25 ягод",
        "Большой набор"
      ],
      "description": "Большой набор из 25 свежих ягод. Карточка и фотография сохранены в текущем виде.",
      "variants": [
        {
          "id": "SET-25-FRESH",
          "type": "fresh",
          "label": "Свежая клубника",
          "price": 2790,
          "prepText": "Приготовим за 20–30 минут",
          "prepMinutes": 30,
          "addOns": true
        }
      ]
    },
    {
      "id": "MIX-BANANA",
      "kind": "set",
      "category": "Наборы",
      "title": "Клубника и бананы",
      "subtitle": "12 ягод клубники + 2 банана в шоколаде",
      "strawberryCount": 12,
      "bananaCount": 2,
      "image": "assets/mix-banana.webp",
      "thumbnail": "assets/mix-banana-thumb.webp",
      "badges": [
        "Ассорти · клубника + банан"
      ],
      "description": "Смешанный свежий набор: 12 ягод клубники и 2 банана в шоколаде.",
      "variants": [
        {
          "id": "MIX-BANANA-C02",
          "type": "fresh",
          "label": "Свежая клубника и бананы",
          "price": 1990,
          "prepText": "Приготовим за 20–30 минут",
          "prepMinutes": 30,
          "addOns": false
        }
      ]
    },
    {
      "id": "BQT-A07",
      "kind": "bouquet",
      "category": "Букеты",
      "title": "Букет A07 — 19 ягод",
      "subtitle": "Свежая клубника в шоколаде",
      "strawberryCount": 19,
      "bananaCount": 0,
      "image": "assets/bqt-a07.webp",
      "thumbnail": "assets/bqt-a07-thumb.webp",
      "badges": [
        "19 ягод",
        "Только свежая"
      ],
      "description": "Букет из 19 свежих ягод в кремовой упаковке.",
      "variants": [
        {
          "id": "BQT-A07-FRESH",
          "type": "fresh",
          "label": "Свежая клубника",
          "price": 2750,
          "prepText": "Приготовим за 30–60 минут",
          "prepMinutes": 60,
          "addOns": false
        }
      ]
    },
    {
      "id": "BQT-A08",
      "kind": "bouquet",
      "category": "Букеты",
      "title": "Букет A08 — 39 ягод",
      "subtitle": "Клубника в шоколаде",
      "strawberryCount": 39,
      "bananaCount": 0,
      "image": "assets/bqt-a08.webp",
      "thumbnail": "assets/bqt-a08-thumb.webp",
      "badges": [
        "39 ягод",
        "Большой букет"
      ],
      "description": "Большой букет из 39 ягод в розово-фиолетовой упаковке.",
      "variants": [
        {
          "id": "BQT-A08-FRESH",
          "type": "fresh",
          "label": "Свежая клубника",
          "price": 4890,
          "prepText": "Приготовим за 30–60 минут",
          "prepMinutes": 60,
          "addOns": false
        },
        {
          "id": "BQT-A08-FD",
          "type": "freeze_dried",
          "label": "Сублимированная клубника",
          "price": 3290,
          "prepText": "В наличии",
          "prepMinutes": 0,
          "addOns": false
        }
      ]
    },
    {
      "id": "BQT-B09",
      "kind": "bouquet",
      "category": "Букеты",
      "title": "Букет B09 — 19 ягод",
      "subtitle": "Клубника в шоколаде",
      "strawberryCount": 19,
      "bananaCount": 0,
      "image": "assets/bqt-b09.webp",
      "thumbnail": "assets/bqt-b09-thumb.webp",
      "badges": [
        "19 ягод"
      ],
      "description": "Букет из 19 ягод в яркой упаковке.",
      "variants": [
        {
          "id": "BQT-B09-FRESH",
          "type": "fresh",
          "label": "Свежая клубника",
          "price": 2790,
          "prepText": "Приготовим за 30–60 минут",
          "prepMinutes": 60,
          "addOns": false
        },
        {
          "id": "BQT-B09-FD",
          "type": "freeze_dried",
          "label": "Сублимированная клубника",
          "price": 1690,
          "prepText": "В наличии",
          "prepMinutes": 0,
          "addOns": false
        }
      ]
    },
    {
      "id": "BQT-B10",
      "kind": "bouquet",
      "category": "Букеты",
      "title": "Букет B10 — 35 ягод",
      "subtitle": "Клубника в шоколаде",
      "strawberryCount": 35,
      "bananaCount": 0,
      "image": "assets/bqt-b10.webp",
      "thumbnail": "assets/bqt-b10-thumb.webp",
      "badges": [
        "35 ягод"
      ],
      "description": "Букет из 35 ягод в коралловой упаковке.",
      "variants": [
        {
          "id": "BQT-B10-FRESH",
          "type": "fresh",
          "label": "Свежая клубника",
          "price": 4390,
          "prepText": "Приготовим за 30–60 минут",
          "prepMinutes": 60,
          "addOns": false
        },
        {
          "id": "BQT-B10-FD",
          "type": "freeze_dried",
          "label": "Сублимированная клубника",
          "price": 2950,
          "prepText": "В наличии",
          "prepMinutes": 0,
          "addOns": false
        }
      ]
    }
  ]
};
