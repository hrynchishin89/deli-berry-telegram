(async () => {
  'use strict';
  let catalog, appConfig;
  const tg=window.Telegram?.WebApp;
  tg?.ready(); tg?.expand();
  async function api(url, options={}) {
    const r=await fetch(url,{...options,headers:{'Content-Type':'application/json','X-Telegram-Init-Data':tg?.initData||'',...options.headers}});
    const d=await r.json();if(!r.ok)throw new Error(d.message||'Не удалось выполнить запрос.');return d;
  }
  const ordersList = document.getElementById('ordersList');
  const orderDetail = document.getElementById('orderDetail');
  const statusFilters = document.getElementById('statusFilters');
  const searchInput = document.getElementById('searchOrders');
  const toastEl = document.getElementById('toast');
  const money = new Intl.NumberFormat('ru-RU');

  const STATUS = {
    ALL: { label: 'Все' },
    WAITING_CONFIRMATION: { label: 'Новые', tone: 'warning' },
    CONFIRMED: { label: 'Подтверждены' },
    PAYMENT_PENDING: { label: 'Ждут оплату', tone: 'warning' },
    PAID: { label: 'Оплачены', tone: 'success' },
    SENT_TO_STORE: { label: 'Переданы в точку' },
    IN_PRODUCTION: { label: 'Готовятся' },
    READY: { label: 'Готовы', tone: 'success' },
    COURIER_ORDERED: { label: 'Курьер вызван' },
    COURIER_PICKED_UP: { label: 'У курьера' },
    DELIVERED: { label: 'Доставлены', tone: 'success' },
    EXPIRED_UNCLAIMED: { label: 'Срок хранения истёк', tone: 'danger' },
    REFUND_PENDING: { label: 'Возврат согласуется', tone: 'warning' },
    REFUNDED: { label: 'Возвращены' },
    COMPLETED: { label: 'Завершены', tone: 'success' },
    CANCELLED: { label: 'Отменены', tone: 'danger' }
  };

  let orders = [], nextBefore = null, loadingOrders = false, ordersInitialized = false;
  let activeId = null;
  let filter = 'ALL';
  let search = '';

  document.getElementById('refreshOrders').addEventListener('click', () => loadOrders());
  document.getElementById('moreOrders').addEventListener('click',()=>loadOrders(true));
  searchInput.addEventListener('input', () => { search = searchInput.value.trim().toLowerCase(); renderList(); });
  statusFilters.addEventListener('click', e => {
    const button = e.target.closest('[data-status]');
    if (!button) return;
    filter = button.dataset.status;
    renderFilters();
    renderList();
  });
  ordersList.addEventListener('click', async e => {
    const item = e.target.closest('[data-order-id]');
    if (!item) return;
    activeId = item.dataset.orderId;
    await loadSelectedHistory();
    renderList();
    renderDetail();
    if (window.innerWidth < 680) orderDetail.scrollIntoView({ behavior: 'smooth' });
  });
  orderDetail.addEventListener('click', handleDetailAction);
  document.getElementById('storeSettings').addEventListener('submit', saveStore);
  try {
    const me=await api('/api/me');if(!me.operator)throw new Error('Доступ разрешён только оператору.');
    [catalog, appConfig]=await Promise.all([api('/api/catalog'),api('/api/config')]);
    document.getElementById('operatorSession').textContent='Оператор авторизован через Telegram'+(appConfig.paymentMode==='sandbox'?' · ТЕСТОВАЯ ОПЛАТА':appConfig.paymentEnabled?'':' · Оплата отключена');
    renderStores();
  } catch(error) { document.getElementById('operatorError').textContent=error.message;return; }
  setInterval(()=>{if(!document.hidden&&!['INPUT','TEXTAREA'].includes(document.activeElement?.tagName))loadOrders();},15000);

  renderFilters();
  loadOrders();

  async function loadOrders(more=false) {
    if(loadingOrders||more&&!nextBefore)return;loadingOrders=true;
    try {
      const result=await api('/api/operator/orders'+(more?'?before='+encodeURIComponent(nextBefore):''));
      const merged=new Map(orders.map(o=>[o.id,o]));for(const order of result.orders)merged.set(order.id,order);orders=[...merged.values()];
      if(more||!ordersInitialized)nextBefore=result.nextBefore;ordersInitialized=true;
      if(activeId&&!result.orders.some(o=>o.id===activeId)){const current=await api('/api/operator/orders/'+activeId);orders=orders.map(o=>o.id===current.order.id?current.order:o);}
      document.getElementById('moreOrders').hidden=!nextBefore;
      const delivery=await api('/api/operator/notifications');
      document.getElementById('operatorError').textContent=delivery.notifications.length ? `Уведомления: ${delivery.notifications.length} ожидают отправки или требуют проверки.` : '';
      if(activeId&&!orders.some(o=>o.id===activeId))activeId=null;
      if(!activeId&&orders.length)activeId=orders[0].id;
      await loadSelectedHistory();renderList();renderDetail();
    } catch(error) { document.getElementById('operatorError').textContent=error.message; }
    finally { loadingOrders=false; }
  }
  async function loadSelectedHistory() {
    const selected=orders.find(o=>o.id===activeId);
    if(!selected?.historyPaginated)return;
    const id=selected.id, history=[];let before=null;
    try {
      do {
        const page=await api('/api/operator/orders/'+id+'/history'+(before?'?before='+before:''));
        history.push(...page.history);before=page.nextBefore;
      } while(before && activeId===id);
      if(activeId===id){selected.history=history.reverse();selected.historyPaginated=false;}
    } catch(error) { document.getElementById('operatorError').textContent=error.message; }
  }
  function renderStores() {
    document.getElementById('storeSettings').innerHTML=catalog.stores.map(store=>`
      <form data-store="${store.id}" class="form-section">
      <h3>${esc(store.shortName)}</h3><div class="field-grid two">
      ${[['name','Название'],['shortName','Короткое название'],['address','Адрес'],['hours','Режим работы']].map(([key,label])=>`<div class="field"><label>${label}<input class="input" name="${key}" value="${esc(store[key])}" required></label></div>`).join('')}
      <div class="field"><label>Открытие (МСК)<input class="input" type="time" name="openTime" value="${store.openTime}" required></label></div>
      <div class="field"><label>Закрытие (МСК)<input class="input" type="time" name="closeTime" value="${store.closeTime}" required></label></div></div>
      <label class="checkbox-card"><input name="enabled" type="checkbox" ${store.enabled?'checked':''}> Принимать заказы в эту точку</label>
      <h4>Недоступные варианты</h4><div class="field-grid two">${catalog.products.flatMap(p=>p.variants.map(v=>`<label class="checkbox-card"><input name="stopList" type="checkbox" value="${v.id}" ${(store.stopList||[]).includes(v.id)?'checked':''}>${esc(p.title)} — ${esc(v.label)}</label>`)).join('')}</div>
      <button class="button secondary" type="submit">Сохранить точку</button></form>`).join('');
  }
  async function saveStore(event) {
    event.preventDefault();const form=event.target,store=catalog.stores.find(s=>s.id===form.dataset.store);if(!store)return;
    const data=new FormData(form), patch={expectedVersion:store.settingsVersion,enabled:data.has('enabled'),stopList:data.getAll('stopList')};
    for(const key of ['name','shortName','address','hours','openTime','closeTime'])patch[key]=data.get(key);
    const button=form.querySelector('button');button.disabled=true;
    try{await api('/api/operator/stores/'+store.id,{method:'PATCH',body:JSON.stringify(patch)});catalog=await api('/api/catalog');renderStores();toast('Настройки сохранены.');}
    catch(error){toast(error.message);}finally{button.disabled=false;}
  }

  function renderFilters() {
    const preferred = Object.keys(STATUS);
    statusFilters.innerHTML = preferred.map(status => `<button class="filter-chip ${status === filter ? 'active' : ''}" data-status="${status}" type="button">${STATUS[status].label}</button>`).join('');
  }

  function renderList() {
    const visible = orders.filter(order => {
      if (filter !== 'ALL' && order.status !== filter) return false;
      if (!search) return true;
      const haystack = [order.id, order.customer?.name, order.customer?.phone, order.product?.title, order.store?.name].join(' ').toLowerCase();
      return haystack.includes(search);
    });
    if (!visible.length) {
      ordersList.innerHTML = `<div class="empty-state">Заказов по этому фильтру нет.</div>`;
      return;
    }
    ordersList.innerHTML = visible.map(order => {
      const status = STATUS[order.status] || { label: order.status };
      return `<article class="operator-order ${order.id === activeId ? 'active' : ''}" data-order-id="${order.id}">
        <div class="order-card-head"><div><div class="order-card-number">${esc(order.id)}</div><div class="order-card-date">${formatDateTime(order.createdAt)}</div></div><span class="status-pill ${status.tone || ''}">${status.label}</span></div>
        <div class="order-card-product">${esc(order.product?.title || '')}</div>
        <div class="order-card-meta">${esc(order.customer?.name || '')} · ${esc(order.customer?.phone || '')}<br>${esc(order.store?.name || '')} · ${esc(order.schedule?.date || '')} ${esc(order.schedule?.time || '')}</div>
      </article>`;
    }).join('');
  }

  function renderDetail() {
    const order = orders.find(o => o.id === activeId);
    if (!order) {
      orderDetail.innerHTML = `<div class="empty-state">Выберите заказ слева.</div>`;
      return;
    }
    const status = STATUS[order.status] || { label: order.status };
    const addOns = (order.addOns || []).map(item => `${esc(item.name)} (+${fmt(item.unitPrice * order.quantity)} ₽)`).join('<br>') || 'Нет';
    const delivery = order.fulfilment?.type === 'courier'
      ? `${esc(order.fulfilment.label)}<br>${esc(order.fulfilment.deliveryAddress || '')}<br><small>Стоимость оплачивается клиентом отдельно.</small>`
      : esc(order.fulfilment?.label || 'Самовывоз');

    orderDetail.innerHTML = `
      <div class="order-card-head">
        <div><div class="detail-kicker">${esc(order.id)}</div><h2>${esc(order.product?.title || '')}</h2></div>
        <span class="status-pill ${status.tone || ''}">${status.label}</span>
      </div>
      <dl class="detail-table">
        <div class="detail-table-row"><dt>Клиент</dt><dd>${esc(order.customer?.name || '')}<br><a href="tel:${phoneDigits(order.customer?.phone)}">${esc(order.customer?.phone || '')}</a></dd></div>
        <div class="detail-table-row"><dt>Товар</dt><dd>${esc(order.variant?.label || '')} · ${order.quantity} шт.<br>${addOns}</dd></div>
        <div class="detail-table-row"><dt>Сумма</dt><dd>${fmt(order.total)} ₽${order.fulfilment?.type === 'courier' ? '<br><small>без доставки</small>' : ''}</dd></div>
        <div class="detail-table-row"><dt>Точка</dt><dd>${esc(order.store?.name || '')}<br>${esc(order.store?.address || '')}</dd></div>
        <div class="detail-table-row"><dt>Дата и время</dt><dd>${esc(order.schedule?.date || '')}, ${esc(order.schedule?.time || '')}</dd></div>
        <div class="detail-table-row"><dt>Получение</dt><dd>${delivery}</dd></div>
        ${order.recipient?.name || order.recipient?.phone ? `<div class="detail-table-row"><dt>Получатель</dt><dd>${esc(order.recipient.name || '')}<br>${esc(order.recipient.phone || '')}</dd></div>` : ''}
        ${order.inscriptionText ? `<div class="detail-table-row"><dt>Надпись</dt><dd>«${esc(order.inscriptionText)}»</dd></div>` : ''}
        <div class="detail-table-row"><dt>Комментарий</dt><dd>${esc(order.comment || 'Нет')}</dd></div>
        <div class="detail-table-row"><dt>Оплата</dt><dd>${esc(order.payment?.provider || 'YANDEX_PAY')} · ${paymentLabel(order.payment?.status)}</dd></div>
      </dl>

      <div class="notice berry"><span>1</span><span>Все действия выполняет один оператор: проверяет заказ, связывается с клиентом и передаёт информацию выбранной точке.</span></div>

      ${order.status === 'IN_PRODUCTION' ? `<div class="field-grid two"><div class="field"><label>Изготовлено (МСК)<input id="manufacturedAt" type="datetime-local" class="input"></label></div><div class="field"><label>Годно до (МСК, с упаковки)<input id="expiresAt" type="datetime-local" class="input"></label></div></div>` : ''}
      ${order.holdUntil ? `<div class="notice warning">Хранить на точке до ${formatDateTime(order.holdUntil)} (МСК).</div>` : ''}
      <div class="operator-actions">
        <a class="button primary" href="tel:${phoneDigits(order.customer?.phone)}">Позвонить клиенту</a>
        <button class="button secondary" data-action="copy-order" type="button">Скопировать заказ</button>
        ${actionButtons(order)}
      </div>
      <div class="field" style="margin-top:14px"><label for="operatorNote">Комментарий оператора</label><textarea id="operatorNote" class="textarea" placeholder="Причина изменения времени, детали доставки…">${esc(order.operatorNote || '')}</textarea></div>
      <button class="button ghost" data-action="save-note" type="button" style="margin-top:8px">Сохранить комментарий</button>
      <div class="form-section"><h3 class="form-title">История</h3>${renderHistory(order)}</div>`;
  }

  function actionButtons(order) {
    const labels={CONFIRMED:'Подтвердить',CANCELLED:'Отменить',SENT_TO_STORE:'Передать в точку',IN_PRODUCTION:'Начать приготовление',READY:'Готов',COMPLETED:'Выдан',COURIER_ORDERED:'Курьер вызван',COURIER_PICKED_UP:'Передан курьеру',DELIVERED:'Доставлен',REFUND_PENDING:'Согласовать возврат'};
    const buttons=(order.allowedTransitions||[]).map(status=>`<button class="button secondary" data-action="status" data-next="${status}">${labels[status]||esc(status)}</button>`);
    if(order.status==='CONFIRMED'&&appConfig.paymentEnabled)buttons.push('<button class="button primary" data-action="payment">Открыть оплату Яндекс Пэй</button>');
    if(order.status==='PAYMENT_PENDING'&&order.payment.status==='CREATING')buttons.push('<button class="button primary" data-action="payment">Повторить запрос ссылки</button>');
    if(order.payment?.status!=='NOT_CREATED')buttons.push('<button class="button ghost" data-action="sync-payment">Проверить платёж</button>');
    if(order.status==='REFUND_PENDING')buttons.push('<p class="form-note">Возврат выполняется в кабинете продавца по согласованной кассовой схеме. Статус обновится после подтверждения Яндекс Пэй.</p>');
    return buttons.join('');
  }
  async function handleDetailAction(event) {
    const button=event.target.closest('[data-action]');if(!button)return;
    const order=orders.find(o=>o.id===activeId);if(!order)return;
    const action=button.dataset.action;
    if(action==='copy-order')return copyOrder(order);
    let endpoint=action, payload={expectedVersion:order.version,note:document.getElementById('operatorNote').value.trim()};
    if(action==='save-note')endpoint='note';
    if(action==='status') {
      payload.status=button.dataset.next;
      if(payload.status==='READY') {
        const manufactured=document.getElementById('manufacturedAt').value,expires=document.getElementById('expiresAt').value;
        if(!manufactured||!expires)return toast('Укажите время изготовления и срок годности.');
        payload.manufacturedAt=manufactured+':00+03:00';payload.expiresAt=expires+':00+03:00';
      }
      if(['CANCELLED','REFUND_PENDING'].includes(payload.status)&&!payload.note)return toast('Укажите причину в комментарии.');
    }
    if(!['note','status','payment','sync-payment'].includes(endpoint))return;
    button.disabled=true;
    try{await api(`/api/operator/orders/${order.id}/${endpoint}`,{method:'POST',body:JSON.stringify(payload)});await loadOrders();toast('Сохранено.');}
    catch(error){toast(error.message);}finally{button.disabled=false;}
  }

  function copyOrder(order) {
    const text = [
      `Заказ ${order.id}`,
      `${order.product.title} — ${order.variant.label}`,
      `Количество: ${order.quantity}`,
      order.addOns?.length ? `Дополнения: ${order.addOns.map(a => a.name).join(', ')}` : '',
      `Сумма: ${fmt(order.total)} ₽`,
      `${order.fulfilment.label}: ${order.fulfilment.deliveryAddress || order.store.address}`,
      `Дата и время: ${order.schedule.date} ${order.schedule.time}`,
      `Клиент: ${order.customer.name}, ${order.customer.phone}`,
      order.comment ? `Комментарий: ${order.comment}` : ''
    ].filter(Boolean).join('\n');
    navigator.clipboard?.writeText(text).then(() => toast('Заказ скопирован')).catch(() => toast(text));
  }

  function renderHistory(order) {
    const history = [...(order.history || [])].reverse();
    return history.length ? history.map(item => `<div class="info-row"><div class="info-icon">•</div><div><div class="info-label">${formatDateTime(item.at)}</div><div class="info-value">${esc(item.note || item.status)}</div></div></div>`).join('') : '<p class="form-note">История пока пуста.</p>';
  }

  function paymentLabel(status) {
    const labels={NOT_CREATED:'не создана',CREATING:'ссылка запрашивается',PENDING:'ожидает оплаты',CAPTURED:'оплачено',FAILED:'не выполнена',REFUNDED:'полный возврат',PARTIALLY_REFUNDED:'частичный возврат',AUTHORIZED:'средства заблокированы',VOIDED:'отменена'};
    return labels[status] || status || 'не создана';
  }

  function fmt(v) { return money.format(Number(v || 0)); }
  function phoneDigits(v = '') { return String(v).replace(/[^+\d]/g, ''); }
  function formatDateTime(value) { try { return new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit',timeZone:'Europe/Moscow' }).format(new Date(value)); } catch (_) { return value; } }
  function esc(value = '') { return String(value).replace(/[&<>'"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c])); }
  function toast(message) { toastEl.textContent = message; toastEl.classList.add('show'); clearTimeout(toast._timer); toast._timer = setTimeout(() => toastEl.classList.remove('show'), 2400); }
})();
