import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const sha=v=>createHash('sha256').update(v).digest('hex');
const manifest=JSON.parse(await readFile('baseline-manifest.json','utf8'));
for(const [name,expected] of Object.entries(manifest))assert.equal(sha(await readFile('public/'+name)),expected,`Business/design baseline changed: ${name}`);
for(const name of await readdir('src')){const code=await readFile('src/'+name,'utf8');assert.doesNotMatch(code,/from\s+['"](?:node:|pg['"]|jose['"]|express['"])/);assert.doesNotMatch(code,/setInterval\(/);}
const config=await readFile('wrangler.toml','utf8');for(const flag of ['ORDERS_ENABLED','TELEGRAM_ENABLED','OWNER_LIVE_APPROVED','LIVE_PAYMENTS_APPROVED'])assert.match(config,new RegExp(flag+' = "false"'));
assert.match(config,/PAYMENT_MODE = "disabled"/);
console.log('Catalogue, images, customer frontend and CSS match release 1.1.1 byte for byte. Runtime has no Node server, pg, jose or ORM. Live gates are OFF.');
