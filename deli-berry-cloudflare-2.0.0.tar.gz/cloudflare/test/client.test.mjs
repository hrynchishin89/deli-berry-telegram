import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import crypto from 'node:crypto';
import {JSDOM} from 'jsdom';
import catalog from '../public/catalog.json' with {type:'json'};

const config={paymentEnabled:false,paymentMode:'disabled',termsUrl:'/legal.html',privacyUrl:'/legal.html'};
const settle=()=>new Promise(r=>setTimeout(r,30));
async function until(fn){for(let i=0;i<50;i++){if(fn())return;await settle();}assert.fail('Не дождались клиентского состояния');}
async function page(t,file='index',handler=()=>null,authenticated=true){
  const dom=new JSDOM(await readFile(new URL('../public/'+file+'.html',import.meta.url),'utf8'),{url:'https://example.test/',runScripts:'outside-only',pretendToBeVisual:true});
  t.after(()=>dom.window.close());const w=dom.window;w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};
  Object.defineProperty(w,'crypto',{value:crypto.webcrypto});w.TextEncoder=TextEncoder;
  const noop=()=>{},button={hide:noop,show:noop,onClick:noop,offClick:noop,setParams:noop};
  w.Telegram={WebApp:{initData:authenticated?'signed-test':'',initDataUnsafe:{user:{first_name:'Тест'}},ready:noop,expand:noop,MainButton:button,BackButton:button}};
  const calls=[];w.fetch=async(url,options={})=>{calls.push({url,options});const custom=await handler(url,options);if(custom)return custom;const data=url==='/api/catalog'?catalog:url==='/api/config'?config:url==='/api/me'?{operator:false}:url==='/api/orders'?{orders:[],nextBefore:null}:url.startsWith('/api/slots?')?{slots:['15:00','15:15','15:30']}:url==='/api/quote'?{total:7777}:null;if(!data)throw new Error('Непредусмотренный запрос '+url);return {ok:true,json:async()=>structuredClone(data)};};
  await w.eval(await readFile(new URL('../public/'+(file==='index'?'app':file)+'.js',import.meta.url),'utf8'));return {w,calls,dom};
}
function click(w,selector){const el=w.document.querySelector(selector);assert.ok(el,selector);el.click();}
function fill(w,selector,value,event='input'){const el=w.document.querySelector(selector);assert.ok(el,selector);if(el.type==='checkbox')el.checked=value;else el.value=value;el.dispatchEvent(new w.Event(event,{bubbles:true}));}
async function checkout(w){await until(()=>w.document.querySelector('[data-action="open-product"]'));click(w,'[data-action="open-product"]');await until(()=>w.document.querySelector('[data-action="checkout"]:not(:disabled)'));click(w,'[data-action="checkout"]');await until(()=>w.document.querySelector('#orderTime option[value="15:15"]'));fill(w,'#orderTime','15:15','change');fill(w,'#customerName','Тестовый клиент');fill(w,'#customerPhone','+79990000000');fill(w,'[data-bind="consent"]',true,'change');}

test('Клиент: сумма от сервера, 15-минутные слоты, ошибка отправки не создаёт фиктивный заказ',async t=>{
  const {w,calls}=await page(t,'index',(url,opts)=>url==='/api/orders'&&opts.method==='POST'?{ok:false,json:async()=>({message:'Тестовый сбой сервера'})}:null);
  await checkout(w);assert.match(w.document.querySelector('.breakdown-line.total').textContent,/7\s777/);
  click(w,'[data-action="submit-order"]');await until(()=>w.document.querySelector('#toast').textContent==='Тестовый сбой сервера');
  assert.ok(w.document.querySelector('#customerPhone'));assert.equal(w.document.querySelector('.success-card'),null);assert.equal(w.localStorage.length,0);
  const request=calls.find(c=>c.url==='/api/orders'&&c.options.method==='POST');assert.ok(request.options.headers['Idempotency-Key']);assert.equal(JSON.parse(request.options.body).total,undefined);
  click(w,'[data-action="submit-order"]');await until(()=>calls.filter(c=>c.url==='/api/orders'&&c.options.method==='POST').length===2);
  const retries=calls.filter(c=>c.url==='/api/orders'&&c.options.method==='POST');assert.equal(retries[0].options.headers['Idempotency-Key'],retries[1].options.headers['Idempotency-Key']);
});
test('Клиент: экран принятого заказа появляется только после ответа API',async t=>{
  const {w}=await page(t,'index',(url,opts)=>url==='/api/orders'&&opts.method==='POST'?{ok:true,json:async()=>({order:{id:'DB-1234567890ABCDEF',status:'WAITING_CONFIRMATION',customer:{phone:'+79990000000'},fulfilment:{type:'pickup'}}})}:null);
  await checkout(w);click(w,'[data-action="submit-order"]');await until(()=>w.document.querySelector('.success-card'));assert.match(w.document.querySelector('.order-number').textContent,/DB-1234567890ABCDEF/);assert.equal(w.sessionStorage.getItem('deliBerry.pending.v2'),null);
});
test('Клиент: заказы без Telegram недоступны, нет демонстрационных данных',async t=>{
  const {w,calls}=await page(t,'index',()=>null,false);await until(()=>w.document.querySelector('[data-route="orders"]'));click(w,'[data-route="orders"]');assert.match(w.document.querySelector('#app').textContent,/Откройте приложение через Telegram/);assert.equal(calls.filter(c=>c.url==='/api/orders').length,0);
});
test('Оператор: чужой Telegram ID не загружает список заказов',async t=>{
  const {w,calls}=await page(t,'operator');assert.match(w.document.querySelector('#operatorError').textContent,/только оператору/);assert.equal(calls.filter(c=>c.url.startsWith('/api/operator/')).length,0);
});
test('Оператор: пользовательский HTML экранирован; ручного подтверждения оплаты нет',async t=>{
  const order={id:'DB-1234567890ABCDEF',status:'WAITING_CONFIRMATION',createdAt:new Date().toISOString(),customer:{name:'<img src=x onerror=alert(1)>',phone:'+79990000000'},product:{title:'Тест'},variant:{label:'Свежая'},quantity:1,total:100,addOns:[{name:'<script>bad()</script>',unitPrice:100}],fulfilment:{type:'pickup',label:'Самовывоз'},store:{name:'Discovery'},schedule:{date:'2026-10-01',time:'15:15'},payment:{status:'NOT_CREATED'},history:[],allowedTransitions:['CONFIRMED','CANCELLED']};
  const {w}=await page(t,'operator',url=>{const d=url==='/api/me'?{operator:true}:url==='/api/operator/orders'?{orders:[order],nextBefore:null}:url==='/api/operator/notifications'?{notifications:[]}:null;return d?{ok:true,json:async()=>d}:null;});
  await until(()=>w.document.querySelector('[data-next="CONFIRMED"]'));assert.equal(w.document.querySelector('#orderDetail img'),null);assert.equal(w.document.querySelector('#orderDetail script'),null);assert.equal(w.document.querySelector('[data-next="PAID"]'),null);
});
