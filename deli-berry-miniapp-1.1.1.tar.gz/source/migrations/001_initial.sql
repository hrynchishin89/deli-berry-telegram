CREATE TABLE IF NOT EXISTS users (telegram_id bigint PRIMARY KEY, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS stores (id text PRIMARY KEY, settings jsonb NOT NULL, version integer NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS orders (
 id text PRIMARY KEY, user_id bigint NOT NULL REFERENCES users(telegram_id),
 request_key text NOT NULL, request_hash text NOT NULL, store_id text NOT NULL REFERENCES stores(id),
 status text NOT NULL CHECK (status IN ('WAITING_CONFIRMATION','CONFIRMED','PAYMENT_PENDING','PAID','SENT_TO_STORE','IN_PRODUCTION','READY','COMPLETED','COURIER_ORDERED','COURIER_PICKED_UP','DELIVERED','CANCELLED','REFUND_PENDING','REFUNDED','EXPIRED_UNCLAIMED')),
 total_kopecks integer NOT NULL CHECK (total_kopecks > 0), data jsonb NOT NULL,
 version integer NOT NULL DEFAULT 1, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(user_id, request_key)
);
CREATE INDEX IF NOT EXISTS orders_user_created ON orders(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS orders_status_created ON orders(status, created_at DESC);
CREATE TABLE IF NOT EXISTS order_events (
 id bigserial PRIMARY KEY, order_id text NOT NULL REFERENCES orders(id), actor text NOT NULL,
 previous_status text, status text NOT NULL, note text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS order_events_order ON order_events(order_id, id);
CREATE TABLE IF NOT EXISTS payments (
 order_id text PRIMARY KEY REFERENCES orders(id), request_id text NOT NULL UNIQUE,
 status text NOT NULL, url text NOT NULL DEFAULT '', request_body jsonb NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS webhook_events (event_key text PRIMARY KEY, received_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS notifications (
 id bigserial PRIMARY KEY, dedupe_key text NOT NULL UNIQUE, chat_id bigint NOT NULL,
 body jsonb NOT NULL, attempts integer NOT NULL DEFAULT 0, next_attempt_at timestamptz NOT NULL DEFAULT now(),
 lease_until timestamptz, delivered_at timestamptz, failed_at timestamptz, last_error text
);
CREATE INDEX IF NOT EXISTS notifications_pending ON notifications(next_attempt_at) WHERE delivered_at IS NULL AND failed_at IS NULL;
CREATE TABLE IF NOT EXISTS audit_events (id bigserial PRIMARY KEY, actor text NOT NULL, action text NOT NULL, data jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS rate_limits (key text PRIMARY KEY, count integer NOT NULL, expires_at timestamptz NOT NULL);
