#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
umask 077
mkdir -p backups
backup_file="backups/deli_berry_$(date -u +%Y%m%dT%H%M%SZ).dump"
trap 'rm -f "$backup_file.tmp"' EXIT HUP INT TERM
docker compose exec -T db sh -c 'exec pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > "$backup_file.tmp"
docker compose exec -T db pg_restore --list < "$backup_file.tmp" >/dev/null
mv "$backup_file.tmp" "$backup_file"
printf '%s\n' "$backup_file"
