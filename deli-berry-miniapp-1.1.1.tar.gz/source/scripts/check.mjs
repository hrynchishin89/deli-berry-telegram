import {readdir,readFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
const files=['server.mjs','public/app.js','public/operator.js',...(await readdir('lib')).filter(f=>f.endsWith('.mjs')).map(f=>'lib/'+f),...(await readdir('scripts')).filter(f=>f.endsWith('.mjs')).map(f=>'scripts/'+f)];
for(const file of files){const r=spawnSync(process.execPath,['--check',file],{stdio:'inherit'});if(r.status)process.exit(r.status);}
const c=JSON.parse(await readFile('public/catalog.json','utf8'));
assert.equal(c.products.length,9);assert.equal(c.products.flatMap(p=>p.variants).length,16);assert.equal(c.fulfilment.orderHours.slotMinutes,15);
for(const p of c.products)for(const asset of [p.thumbnail,p.image,...(p.photos||[])].filter(v=>typeof v==='string'))await readFile('public/'+asset);
assert.deepEqual(c,JSON.parse(await readFile('../data/catalog.json','utf8')));
console.log('Синтаксис, каталог и изображения: OK');
