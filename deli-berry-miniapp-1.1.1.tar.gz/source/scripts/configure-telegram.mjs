// Run only after HTTPS is deployed. Secrets come from the environment, never CLI arguments.
import {telegramCall} from '../lib/telegram.mjs';
const token=process.env.TELEGRAM_BOT_TOKEN||process.env.BOT_TOKEN,origin=process.env.APP_ORIGIN||process.env.RENDER_EXTERNAL_URL||process.env.PUBLIC_URL,expectedId=process.env.TELEGRAM_BOT_ID;
if(!token||!expectedId)throw new Error('Set TELEGRAM_BOT_TOKEN and TELEGRAM_BOT_ID securely in the environment.');
const call=(method,body={})=>telegramCall({botToken:token},method,body);
try{
  const me=await call('getMe');
  if(String(me.id)!==expectedId)throw new Error('Bot ID mismatch. No configuration changed.');
  const webhook=await call('getWebhookInfo'),menu=await call('getChatMenuButton');
  console.log(JSON.stringify({botId:me.id,username:me.username,name:me.first_name,webhookUrl:webhook.url,pendingUpdates:webhook.pending_update_count,menu},null,2));
  if(process.argv.includes('--apply')){
    const secret=process.env.TELEGRAM_WEBHOOK_SECRET;
    if(!origin||new URL(origin).origin!==origin||!origin.startsWith('https://')||!secret||!/^[A-Za-z0-9_-]{32,256}$/.test(secret))throw new Error('HTTPS origin and webhook secret required.');
    const health=await fetch(origin+'/api/health',{signal:AbortSignal.timeout(10000)});
    if(!health.ok||(await health.json()).status!=='ok')throw new Error('Application health check failed.');
    await call('setWebhook',{url:origin+'/api/telegram/webhook',secret_token:secret,allowed_updates:['message'],drop_pending_updates:false});
    await call('setMyName',{name:'Дели Берри'});
    await call('setChatMenuButton',{menu_button:{type:'web_app',text:'Заказать',web_app:{url:origin+'/'}}});
    const check=await call('getWebhookInfo');
    if(check.url!==origin+'/api/telegram/webhook')throw new Error('Webhook verification failed.');
    console.log('Название, меню и webhook сохранены. Проверьте /start, Mini App и доступ оператора в Telegram.');
  }else console.log('Read-only inspection. Use --apply only after approving this bot and HTTPS deployment.');
}catch(error){console.error(error.message.includes(token)?'Telegram configuration failed.':error.message);process.exitCode=1;}
