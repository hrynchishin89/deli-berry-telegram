import http from 'node:http';
import path from 'node:path';
import crypto from 'node:crypto';
import {isIP} from 'node:net';
import {readFile,stat} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {loadConfig} from './lib/config.mjs';
import {connectDatabase,migrate} from './lib/db.mjs';
import {telegramUser,isOperator,requireOperator} from './lib/auth.mjs';
import {OrderService} from './lib/service.mjs';
import {YandexPay} from './lib/yandex-pay.mjs';
import {botWebhook,deliverNotifications} from './lib/telegram.mjs';
import {AppError,fail,price,slots} from './lib/domain.mjs';

const PUBLIC=path.join(path.dirname(fileURLToPath(import.meta.url)),'public');
export const catalog=JSON.parse(await readFile(path.join(PUBLIC,'catalog.json'),'utf8'));
export function headers(){return {'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Permissions-Policy':'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy':"default-src 'self'; script-src 'self' https://telegram.org; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'self' https://web.telegram.org https://*.telegram.org"};}
function json(res,status,value){res.writeHead(status,{...headers(),'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));}
async function body(req,raw=false){let size=0;const parts=[];for await(const part of req){size+=part.length;if(size>65536)fail(413,'BODY_TOO_LARGE','Слишком большой запрос.');parts.push(part);}const value=Buffer.concat(parts).toString('utf8');if(raw)return value;try{const o=JSON.parse(value);if(!o||typeof o!=='object'||Array.isArray(o))throw 0;return o;}catch{fail(400,'INVALID_JSON','Некорректный запрос.');}}
export async function createApp({config,db,provider=new YandexPay(config),clock}={}) {
  const service=new OrderService(db,catalog,config,provider,clock);
  async function limit(key,max){const bucket=Math.floor(Date.now()/60000);const k=crypto.createHash('sha256').update(key+':'+bucket).digest('hex');const r=await db.query("INSERT INTO rate_limits(key,count,expires_at) VALUES($1,1,now()+interval '2 minutes') ON CONFLICT(key) DO UPDATE SET count=rate_limits.count+1 RETURNING count",[k]);if(r.rows[0].count>max)fail(429,'RATE_LIMIT','Слишком много запросов. Попробуйте через минуту.');}
  const server=http.createServer(async(req,res)=>{
    const requestId=crypto.randomUUID();res.setHeader('X-Request-Id',requestId);
    try{
      const url=new URL(req.url,config.origin), p=url.pathname;
      if(p.startsWith('/api/')) {
        if(req.headers.origin&&req.headers.origin!==new URL(config.origin).origin)fail(403,'ORIGIN_REJECTED','Недопустимый источник запроса.');
        if(p==='/api/health'&&req.method==='GET'){await db.query('SELECT 1');return json(res,200,{status:'ok'});}
        const forwarded=String(req.headers['x-forwarded-for']||'');
        const clientIp=config.trustProxy&&isIP(forwarded)?forwarded:req.socket.remoteAddress;
        await limit('ip:'+clientIp,600);
        if(p==='/api/config'&&req.method==='GET')return json(res,200,{paymentEnabled:provider.enabled(),paymentMode:config.paymentMode,termsUrl:config.termsUrl||'/legal.html',privacyUrl:config.privacyUrl||'/legal.html',environment:config.production?'production':'development'});
        if(p==='/api/catalog'&&req.method==='GET')return json(res,200,await service.getCatalog());
        if(p==='/api/slots'&&req.method==='GET')return json(res,200,{slots:slots(await service.getCatalog(),url.searchParams.get('variant'),url.searchParams.get('store'),url.searchParams.get('date'),service.clock()),timeZone:'Europe/Moscow'});
        if(p==='/api/quote'&&req.method==='POST'){const q=price(catalog,await body(req));return json(res,200,{total:q.total,quantity:q.quantity,unitPrice:q.variant.price,addOns:q.addOns});}
        if(p==='/api/payments/yandex-pay/v1/webhook'&&req.method==='POST'){const event=await provider.verify(await body(req,true));await service.webhook(event);return json(res,200,{status:'success'});}
        if(p==='/api/telegram/webhook'&&req.method==='POST'){await botWebhook(service,String(req.headers['x-telegram-bot-api-secret-token']||''),await body(req));return json(res,200,{ok:true});}
        const user=telegramUser(String(req.headers['x-telegram-init-data']||''),config.botToken,config.authMaxAge);
        await limit('user:'+user.id,120);
        if(p==='/api/me'&&req.method==='GET')return json(res,200,{id:user.id,operator:isOperator(user,config)});
        if(p.startsWith('/api/operator/'))requireOperator(user,config);
        if(p==='/api/orders'&&req.method==='POST'){await limit('new-order:'+user.id,10);return json(res,201,{order:await service.create(await body(req),user,req.headers['idempotency-key'])});}
        if(p==='/api/orders'&&req.method==='GET')return json(res,200,await service.list(user,false,url.searchParams.get('before')));
        if(p==='/api/operator/orders'&&req.method==='GET')return json(res,200,await service.list(user,true,url.searchParams.get('before')));
        if(p==='/api/operator/notifications'&&req.method==='GET')return json(res,200,{notifications:(await db.query('SELECT id,attempts,last_error,failed_at FROM notifications WHERE delivered_at IS NULL ORDER BY id DESC LIMIT 100')).rows});
        const own=p.match(/^\/api\/orders\/(DB-[A-F0-9]{16})$/);
        if(own&&req.method==='GET')return json(res,200,{order:await service.read(own[1],user)});
        const op=p.match(/^\/api\/operator\/orders\/(DB-[A-F0-9]{16})(?:\/(status|note|payment|sync-payment))?$/);
        if(op){
          if(req.method==='GET'&&!op[2])return json(res,200,{order:await service.read(op[1],user,true)});
          if(req.method==='POST'){
            if(op[2]==='status')return json(res,200,{order:await service.transition(op[1],await body(req),user)});
            if(op[2]==='note')return json(res,200,{order:await service.note(op[1],await body(req),user)});
            if(op[2]==='payment')return json(res,200,{order:await service.createPayment(op[1],user)});
            if(op[2]==='sync-payment'){await service.reconcile(op[1]);return json(res,200,{order:await service.read(op[1],user,true)});}
          }
        }
        const store=p.match(/^\/api\/operator\/stores\/([a-z]+)$/);
        if(store&&req.method==='PATCH')return json(res,200,{store:await service.updateStore(store[1],await body(req),user)});
        return json(res,404,{error:'NOT_FOUND',message:'Страница не найдена.'});
      }
      if(!['GET','HEAD'].includes(req.method))return json(res,405,{error:'METHOD_NOT_ALLOWED'});
      const requested=decodeURIComponent(p==='/'?'/index.html':p);
      if(requested.includes('demo-payment')||requested.split('/').some(part=>part.startsWith('.')))return json(res,404,{error:'NOT_FOUND'});
      const target=path.resolve(PUBLIC,'.'+requested);
      if(!target.startsWith(PUBLIC+path.sep))return json(res,404,{error:'NOT_FOUND'});
      let info;try{info=await stat(target);}catch{return json(res,404,{error:'NOT_FOUND'});}
      if(!info.isFile())return json(res,404,{error:'NOT_FOUND'});
      const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.webp':'image/webp','.png':'image/png'};
      res.writeHead(200,{...headers(),'Content-Type':mime[path.extname(target)]||'application/octet-stream','Cache-Control':requested.startsWith('/assets/')?'public,max-age=86400':'no-store'});
      if(req.method==='HEAD')return res.end();createReadStream(target).on('error',()=>res.destroy()).pipe(res);
    }catch(error){
      const status=error instanceof AppError?error.status:500;
      if(status>=500)console.error(JSON.stringify({event:'request_failed',requestId,code:error.code||'INTERNAL_ERROR'}));
      if(!res.headersSent)json(res,status,{error:error.code||'INTERNAL_ERROR',message:status===500?'Сервис временно недоступен. Заказ не подтверждён. Повторите отправку позже.':error.message,requestId});else res.destroy();
    }
  });
  server.requestTimeout=15000;server.headersTimeout=10000;
  return {server,service};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const config=loadConfig(),db=await connectDatabase(config);await migrate(db,catalog);
  const {server,service}=await createApp({config,db});
  let stopping=false,running=false,work=Promise.resolve();
  const timer=setInterval(()=>{if(running||stopping)return;running=true;work=(async()=>{try{await service.expire();if(config.botToken)await deliverNotifications(db,config);await db.query('DELETE FROM rate_limits WHERE expires_at<now()');}catch(e){console.error(JSON.stringify({event:'worker_failed',code:e.code||'INTERNAL_ERROR'}));}finally{running=false;}})();},5000);timer.unref();
  server.listen(config.port,config.host,()=>console.log(`Дели Берри: ${config.origin}; оплата: ${config.paymentMode}`));
  for(const signal of ['SIGTERM','SIGINT'])process.once(signal,()=>{stopping=true;clearInterval(timer);server.close(async()=>{await work;await db.close();process.exit(0);});setTimeout(()=>process.exit(1),20000).unref();});
}
