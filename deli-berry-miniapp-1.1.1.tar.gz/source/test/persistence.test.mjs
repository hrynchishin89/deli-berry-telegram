import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {catalog} from '../server.mjs';
import {connectDatabase,migrate} from '../lib/db.mjs';
import {loadConfig} from '../lib/config.mjs';
import {OrderService} from '../lib/service.mjs';

test('Заказ и стоп-лист сохраняются после закрытия и повторного открытия локальной PostgreSQL-базы',async()=>{
  const dir=await mkdtemp(path.join(tmpdir(),'deli-berry-persistence-'));
  const c=loadConfig({PGLITE_PATH:dir});let db;
  try{
    db=await connectDatabase(c);await migrate(db,catalog);let s=new OrderService(db,catalog,c,{},()=>new Date('2026-09-29T00:00:00Z'));
    const order=await s.create({product:{id:'SET-12'},variant:{id:'SET-12-FRESH'},quantity:1,store:{id:'discovery'},schedule:{date:'2026-10-01',time:'15:15'},fulfilment:{type:'pickup'},customer:{name:'Тест',phone:'+79990000000'},consent:true},{id:12},crypto.randomUUID());
    await s.updateStore('zelenopark',{expectedVersion:1,stopList:['SET-12-FRESH']},{id:900});await db.close();
    db=await connectDatabase(c);await migrate(db,catalog);s=new OrderService(db,catalog,c,{});
    assert.equal((await s.read(order.id,{id:12})).status,'WAITING_CONFIRMATION');assert.deepEqual((await s.getCatalog()).stores.find(v=>v.id==='zelenopark').stopList,['SET-12-FRESH']);
  }finally{await db?.close();await rm(dir,{recursive:true,force:true});}
});
