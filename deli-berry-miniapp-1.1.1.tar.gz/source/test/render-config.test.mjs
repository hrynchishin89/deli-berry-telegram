import {test} from 'node:test';
import assert from 'node:assert/strict';
import {loadConfig} from '../lib/config.mjs';

test('Render reuses BOT_TOKEN, retains explicit settings, and still blocks incomplete production',()=>{
  const c=loadConfig({BOT_TOKEN:'test-existing-token',RENDER_EXTERNAL_URL:'https://example.onrender.com'});
  assert.equal(c.botToken,'test-existing-token');
  assert.equal(c.origin,'https://example.onrender.com');
  const explicit=loadConfig({BOT_TOKEN:'test-old',TELEGRAM_BOT_TOKEN:'test-new',APP_ORIGIN:'https://example.test',RENDER_EXTERNAL_URL:'https://example.onrender.com'});
  assert.equal(explicit.botToken,'test-new');
  assert.equal(explicit.origin,'https://example.test');
  assert.throws(()=>loadConfig({NODE_ENV:'production',BOT_TOKEN:'test-existing-token',RENDER_EXTERNAL_URL:'https://example.onrender.com'}));
});
